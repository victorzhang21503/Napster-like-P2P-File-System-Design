package com.asu.model;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.util.Properties;
import java.util.Scanner;

public class Client1Test {
	public static final String PATH = "sharedPath";
	public static final String PROP_FILE = "config.properties";
	public static final String SERVER_IP = "serverIP";
	public static final String CLIENT_IP = "clientIP";
	public static final String CLIENT_PORT = "clientPort";

	public static void main(String[] args) {
		Properties prop = new Properties();
		FileInputStream inputStream = null;
		try {
			inputStream = new FileInputStream(PROP_FILE);
			prop.load(inputStream);
			String sharedPath = prop.getProperty(PATH);
			String serverIP = prop.getProperty(SERVER_IP);
			String clientAdd = prop.getProperty(CLIENT_IP);
			int clientPort = Integer.parseInt(prop.getProperty(CLIENT_PORT));

			// directory server port.
			int serverPort = 8080;
			// client host address.
			InetAddress hostClient = InetAddress.getByName(clientAdd);
			// directory server host address.
			InetAddress hostServer = InetAddress.getByName(serverIP);

			Client1 client = new Client1(clientPort, hostClient, sharedPath);
			Thread thread = new Thread(client);
			thread.start();
			Scanner scan = new Scanner(System.in);
			while (true) {
				String searchFile = "";
				System.out.println("1. Inform and Update");
				System.out.println("2. Query for Content");
				System.out.println("3. Exit");
				System.out.println("select the operation 1, 2, 3");
				int request = scan.nextInt();
				scan.nextLine();
				if (request == 2) {
					System.out
							.println("Please enter any specific file name that you want to search or enter 'all' to get complete Directory.");
					searchFile = scan.nextLine();
				}
				client.sendHttpRequest(hostServer, serverPort, request,
						searchFile);
				if (request == 2) {
					System.out.println("Connect with transient client? (y/n)");
					String decision = scan.nextLine();
					if (decision.equalsIgnoreCase("y")) {
						System.out
								.println("Enter the ip of client to connect to.");
						String clientIP = scan.nextLine();
						System.out
								.println("Enter the port of client to connect to.");
						int clientPortDes = scan.nextInt();
						scan.nextLine();
						System.out
								.println("Enter the file name that you want to receive.");
						String fileName = scan.nextLine();
						Client1 miniclient = new Client1(clientIP,
								clientPortDes);
						miniclient.downloadFile(fileName);
					}
				}
				if (request == 3) {
					client.stop();
					break;
				}

			}
			scan.close();
		} catch (IOException e) {
			System.out.println(e);
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException ioExp) {
					System.out.println("Exception while closing input Stream. "
							+ ioExp);
				}
			}
		}

	}

}

package com.asu.model;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.URLDecoder;
import java.util.StringTokenizer;

public class ProcessRequest implements Runnable {
	protected Socket clientSocket = null;
	private static final String CR = "\r";
	private static final String LF = "\n";
	private static final String SLASH = "/";
	File sharedPath;
	BufferedReader input;
	DataOutputStream output;

	public ProcessRequest(Socket clientSocket, File folder) {
		this.clientSocket = clientSocket;
		this.sharedPath = folder;
	}

	public void run() {
		try {
			input = new BufferedReader(new InputStreamReader(
					clientSocket.getInputStream()));
			output = new DataOutputStream(clientSocket.getOutputStream());
			StringTokenizer tokenizer = new StringTokenizer(input.readLine());
			String httpMethod = tokenizer.nextToken();
			String queryString = tokenizer.nextToken();
			String httpVersion = tokenizer.nextToken();
			httpVersion = httpVersion.split(SLASH)[1];
			if (httpMethod.equals("GET")) {
				if (httpVersion.equals("1.1")) {
					if (queryString.equals(SLASH)) {
						sendResponse(200, null);
					} else {
						String fileName = queryString.replace(SLASH, "");
						fileName = URLDecoder.decode(fileName, "utf-8");
						File myFile = new File(sharedPath + SLASH + fileName);
						if (myFile.isFile()) {
							sendResponse(200, myFile);
						} else {
							sendResponse(404, null);
						}
					}
				} else {
					sendResponse(505, null);
				}
			} else {
				sendResponse(400, null);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void sendResponse(int statusCode, File myFile) throws IOException {
		byte[] mybytearray = null;
		String statusLine = "";
		if (statusCode == 200) {
			statusLine = "HTTP/1.1 200 OK" + CR + LF;
		} else if (statusCode == 400) {
			statusLine = "HTTP/1.1 400 Bad Request" + CR + LF;
		} else if (statusCode == 404) {
			statusLine = "HTTP/1.1 404 Resource not Found" + CR + LF;
		} else {
			statusLine = "HTTP/1.1 505 Version not supported" + CR + LF;
		}
		if (myFile != null) {
			mybytearray = new byte[(int) myFile.length()];
			FileInputStream fis = new FileInputStream(myFile);
			BufferedInputStream bis = new BufferedInputStream(fis);
			bis.read(mybytearray, 0, mybytearray.length);
			bis.close();
		}
		output.writeBytes(statusLine);
		if (mybytearray != null) {
			output.writeInt(mybytearray.length);
			output.write(mybytearray, 0, mybytearray.length);
		} else {
			output.writeInt(0);
		}
		output.flush();
	}
}

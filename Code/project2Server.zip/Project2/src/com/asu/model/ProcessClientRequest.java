package com.asu.model;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ProcessClientRequest implements Runnable {

	private byte[] data;
	private DatagramSocket socket;
	InetAddress clientAddress;
	int clientPort;
	private static List<FileInfo> listOfData = new ArrayList<FileInfo>();

	public ProcessClientRequest(DatagramSocket socket, byte[] data,
			InetAddress clientAdd, int clientPort) {
		this.data = data;
		this.socket = socket;
		this.clientAddress = clientAdd;
		this.clientPort = clientPort;
	}

	@Override
	public void run() {
		String s = new String(data);
		response(s.trim());
	}

	private synchronized void loadData(String data) {
		String[] arr = data.split("\r\n");
		String[] split = arr[0].split("%");
		String address = split[2];
		int port = Integer.parseInt(split[3]);
		for (int i = 1; i < arr.length; i++) {
			FileInfo fileInfo = new FileInfo();
			String[] files = arr[i].split("%");
			fileInfo.setAddress(address);
			fileInfo.setPort(port);
			fileInfo.setFileName(files[0]);
			fileInfo.setFileSize(Integer.parseInt(files[1]));
			if (!listOfData.contains(fileInfo)) {
				listOfData.add(fileInfo);
			}
		}
	}

	private void response(String s) {
		String[] arr = s.split("\r\n");
		String[] split = arr[0].split("%");
		String seqNum = split[0];
		if (s.contains("Inform and Update")) {
			List<String> responses = new ArrayList<String>();
			loadData(s);
			responses.add(seqNum + " 200- ok");
			send(responses);
		} else if (s.contains("Query for Content")) {
			send(getQueryResult(s));
		} else if (s.contains("Exit")) {
			removeEntryFromServer(s);
		}
	}

	private void removeEntryFromServer(String s) {
		String[] arr = s.split("\r\n");
		String[] split = arr[0].split("%");
		String address = split[1];
		int port = Integer.parseInt(split[2]);
		Iterator<FileInfo> iterator = listOfData.iterator();
		while (iterator.hasNext()) {
			FileInfo info = iterator.next();
			if (address.equals(info.getAddress()) && port == info.getPort()) {
				iterator.remove();
			}
		}
	}

	private List<String> getQueryResult(String s) {
		String[] arr = s.split("\r\n");
		String searchFile = arr[1];
		String lastResponse = "";
		List<String> responses = new ArrayList<String>();
		String limitedFiles = "";
		int offset = 128;
		if (!listOfData.isEmpty()) {
			if (searchFile.equalsIgnoreCase("all")) {
				for (FileInfo info : listOfData) {
					lastResponse = info.getAddress() + ":" + info.getPort()
							+ " " + info.getFileName() + " "
							+ info.getFileSize() + "\n";
					if ((limitedFiles + lastResponse).length() <= offset) {
						limitedFiles = limitedFiles + lastResponse;
					} else {
						responses.add(limitedFiles);
						limitedFiles = lastResponse;
					}
				}
				responses.add(limitedFiles);
			} else {
				for (FileInfo info : listOfData) {
					if (searchFile.equals(info.getFileName())) {
						lastResponse = info.getAddress() + ":" + info.getPort()
								+ " " + info.getFileName() + " "
								+ info.getFileSize() + "\n";
						if ((limitedFiles + lastResponse).length() <= offset) {
							limitedFiles = limitedFiles + lastResponse;
						} else {
							responses.add(limitedFiles);
							limitedFiles = lastResponse;
						}
					}
				}
				responses.add(limitedFiles);
				if (limitedFiles.isEmpty()) {
					lastResponse = "400 - File not found.";
					responses.add(lastResponse);
				}
			}
		} else {
			lastResponse = "400 - File not found.";
			responses.add(lastResponse);
		}
		responses.add("end");
		return responses;
	}

	private void send(List<String> responses) {
		for (String response : responses) {
			DatagramPacket dp = new DatagramPacket(response.getBytes(),
					response.getBytes().length, clientAddress, clientPort);
			try {
				this.socket.send(dp);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}

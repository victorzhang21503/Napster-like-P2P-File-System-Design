package com.asu.model;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Client1 extends Client implements Runnable {

	private ExecutorService executorService = Executors.newFixedThreadPool(10);
	private static final String CR = "\r";
	private static final String LF = "\n";
	private static final String PERCENT = "%";
	private int clientPort;
	static File folder;

	/**
	 * Constructor for the client. UDP communication
	 * 
	 * @param port
	 * @param address
	 */
	public Client1(int port, InetAddress address, String sharedPath) {
		try {
			this.clientPort = port;
			sock = new DatagramSocket(port, address);
			folder = new File(sharedPath);
		} catch (SocketException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Constructor for the client. TCP communication.
	 * 
	 * @param ip
	 * @param port
	 */
	public Client1(String ip, int port) {
		try {
			socket = new Socket(ip, port);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void sendHttpRequest(InetAddress address, int port, int reqNumber,
			String searchFile) {
		String method = "";
		List<String> requests = null;
		switch (reqNumber) {
		case 1:
			System.out.println("Inform and Update Server.");
			method = "Inform and Update";
			requests = createHttpRequest(method, searchFile);
			sendPackets(address, port, requests, reqNumber);
			break;
		case 2:
			System.out.println("Query for the content.");
			method = "Query for Content";
			requests = createHttpRequest(method, searchFile);
			sendPackets(address, port, requests, reqNumber);
			break;
		case 3:
			System.out.println("Exit.");
			method = "Exit";
			String request = method + PERCENT
					+ sock.getLocalAddress().getHostAddress() + PERCENT
					+ sock.getLocalPort() + CR + LF;
			sendPacketForExit(address, port, request);
		}
	}

	private void sendPacketForExit(InetAddress address, int port, String request) {
		byte[] originalbytes = request.getBytes();
		DatagramPacket dp = new DatagramPacket(originalbytes,
				originalbytes.length, address, port);
		try {
			sock.send(dp);
		} catch (IOException e) {
			System.out
					.println("socket is closed. Not able to delete entry from server.");
		}
	}

	private void sendPackets(InetAddress address, int port,
			List<String> requests, int reqNumber) {
		for (String request : requests) {
			byte[] originalbytes = request.getBytes();
			DatagramPacket dp = new DatagramPacket(originalbytes,
					originalbytes.length, address, port);
			try {
				sock.send(dp);
				receiveFromServer(reqNumber, dp, 1000);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private List<String> createHttpRequest(String method, String searchFile) {
		List<File> files = getAllFiles(folder);
		int seqNum = 1;
		List<String> requests = new ArrayList<String>();
		String request = method + PERCENT
				+ sock.getLocalAddress().getHostAddress() + PERCENT
				+ sock.getLocalPort() + CR + LF;
		String limitedFiles = "";
		String reqWithSequence = seqNum + PERCENT + request;
		int offset;
		if (searchFile.isEmpty()) {
			for (File file : files) {
				reqWithSequence = seqNum + PERCENT + request;
				offset = 126 - reqWithSequence.length();
				String lastFile = file.getName() + PERCENT + file.length() + CR
						+ LF;
				if ((limitedFiles + lastFile).length() <= offset) {
					limitedFiles = limitedFiles + lastFile;
				} else {
					String req = reqWithSequence + limitedFiles + CR + LF;
					requests.add(req);
					limitedFiles = lastFile;
					seqNum++;
				}
			}
		} else {
			limitedFiles = searchFile;
		}
		request = reqWithSequence + limitedFiles + CR + LF;
		requests.add(request);
		return requests;
	}

	@Override
	public void receiveFromServer(int reqNumber, DatagramPacket dp, int timeOut)
			throws IOException {
		String s;
		System.out.println("receiving data from server.");
		sock.setSoTimeout(timeOut);
		// now receive reply
		// buffer to receive incoming data
		if (reqNumber == 1) {
			try {
				byte[] buffer = new byte[128];
				DatagramPacket reply = new DatagramPacket(buffer, buffer.length);
				sock.receive(reply);
				byte[] data = reply.getData();
				s = new String(data);
				System.out.println(s.trim());
			} catch (java.net.SocketTimeoutException exp) {
				System.out
						.println("retransmitting the same packet due to time out.");
				sock.send(dp);
				receiveFromServer(reqNumber, dp, 2 * timeOut);
			}
		} else {
			while (true) {
				try {
					byte[] buffer = new byte[128];
					DatagramPacket reply = new DatagramPacket(buffer,
							buffer.length);
					sock.receive(reply);
					byte[] data = reply.getData();
					s = new String(data);
					if (s.trim().equalsIgnoreCase("end")) {
						break;
					}
					System.out.println(s.trim());
				} catch (java.net.SocketTimeoutException exp) {
					System.out.println("Cannot connect to the server..");
					break;
				}
			}
		}
	}

	public void downloadFile(String fileName) {
		DataInputStream input = null;
		DataOutputStream output = null;
		try {
			String httpRequest = "GET /" + URLEncoder.encode(fileName, "utf-8")
					+ " HTTP/1.1" + LF;
			input = new DataInputStream(socket.getInputStream());
			output = new DataOutputStream(socket.getOutputStream());
			output.writeBytes(httpRequest);
			output.flush();
			if (input != null) {
				String response = input.readLine();
				System.out.println(response);
				int fileLength = input.readInt();
				if (fileLength > 0) {
					FileOutputStream fos = null;
					BufferedOutputStream bos = null;
					fos = new FileOutputStream(folder + "/" + fileName);
					bos = new BufferedOutputStream(fos);

					byte[] bytes = new byte[fileLength];
					for (int i = 0; i < fileLength; i++) {
						bytes[i] = input.readByte();
					}
					bos.write(bytes);
					bos.flush();
					bos.close();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		openServerSocket();
		while (!isStopped()) {
			Socket clientSocket = null;
			try {
				clientSocket = this.serverSocket.accept();
			} catch (IOException e) {
				if (isStopped()) {
					System.out.println("Server Stopped.");
					break;
				}
				throw new RuntimeException("Error accepting client connection",
						e);
			}
			this.executorService.execute(new ProcessRequest(clientSocket,
					folder));
		}
		this.executorService.shutdown();
		System.out.println("Server Stopped.");
	}

	private void openServerSocket() {
		try {
			this.serverSocket = new ServerSocket(this.clientPort);
		} catch (IOException e) {
			throw new RuntimeException("Cannot open port", e);
		}
	}
}

package com.asu.model;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Server implements Runnable {

	private int serverPort = 8080;
	private DatagramSocket socket;
	private boolean isStopped;
	private ExecutorService executorService = Executors.newFixedThreadPool(10);

	public Server(int port) {
		this.serverPort = port;
	}

	public Server() {
	}

	@Override
	public void run() {
		try {
			this.socket = new DatagramSocket(serverPort);
			// buffer to receive incoming data
			while (!isStopped()) {
				byte[] buffer = new byte[128];
				DatagramPacket incoming = new DatagramPacket(buffer, buffer.length);
				this.socket.receive(incoming);
				byte[] data = incoming.getData();
				InetAddress clientAddress = incoming.getAddress();
				int clientPort = incoming.getPort();
				this.executorService.execute(new ProcessClientRequest(
						this.socket, data, clientAddress, clientPort));
			}
			System.out.println("Server Stopped.");
			this.executorService.shutdown();
		} catch (IOException e) {
			System.out.println(e);
		}
	}

	public synchronized boolean isStopped() {
		return this.isStopped;
	}

	public synchronized void stop() {
		this.isStopped = true;
		this.socket.close();
	}
}

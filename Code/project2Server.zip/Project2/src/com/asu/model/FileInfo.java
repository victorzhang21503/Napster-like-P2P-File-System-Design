package com.asu.model;

public class FileInfo {

	private int port;
	private String address;
	private String fileName;
	private int fileSize;

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public int getFileSize() {
		return fileSize;
	}

	public void setFileSize(int fileSize) {
		this.fileSize = fileSize;
	}

	@Override
	public int hashCode() {
		return port * fileSize;
	}

	@Override
	public boolean equals(Object obj) {
		boolean isEqual = false;
		if (obj != null && obj instanceof FileInfo) {
			isEqual = (this.address.equals(((FileInfo) obj).address)
					&& this.port == ((FileInfo) obj).port
					&& this.fileName.equals(((FileInfo) obj).fileName) && this.fileSize == ((FileInfo) obj).fileSize);
		}
		return isEqual;
	}
}

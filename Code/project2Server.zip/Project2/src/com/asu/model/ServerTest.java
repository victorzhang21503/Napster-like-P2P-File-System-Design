package com.asu.model;

public class ServerTest {

	public static void main(String[] args) {
		Server server = new Server();
		Thread thread = new Thread(server);
		thread.start();
		try {
			Thread.sleep(2000 * 1000);
		} catch (InterruptedException exp) {
			System.out.println(exp);
		}
		System.out.println("Stopping the server...");
		server.stop();
	}
}

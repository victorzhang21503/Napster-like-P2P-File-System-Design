package com.asu.model;

import java.io.File;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

/**
 * The Class Client.
 */
public abstract class Client {

	/** The files. */
	List<File> files = new ArrayList<File>();

	/** The sock. */
	DatagramSocket sock;

	/** The socket. */
	Socket socket;

	/** The server socket. */
	ServerSocket serverSocket;

	/** The is stopped. */
	boolean isStopped = false;

	/**
	 * Send http request.
	 *
	 * @param address
	 *            This is the address of the server.
	 * @param port
	 *            port of the server.
	 * @param reqNumber
	 *            type of request.
	 * @param searchFile
	 *            the search file
	 */
	public abstract void sendHttpRequest(InetAddress address, int port,
			int reqNumber, String searchFile);

	/**
	 * Receive from server.
	 *
	 * @param reqNumber
	 *            the req number
	 * @param dp
	 *            the datagram packet.
	 * @param timeOut
	 *            the time out
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public abstract void receiveFromServer(int reqNumber, DatagramPacket dp,
			int timeOut) throws IOException;

	/**
	 * Gets the all files.
	 *
	 * @param fileorfolder
	 *            the fileorfolder
	 * @return the all files
	 */
	public List<File> getAllFiles(File fileorfolder) {
		if (fileorfolder.isDirectory()) {
			for (File file : fileorfolder.listFiles()) {
				getAllFiles(file);
			}
		} else {
			if (!files.contains(fileorfolder)) {
				files.add(fileorfolder);
			}
		}
		return files;
	}

	/**
	 * Stop.
	 */
	public synchronized void stop() {
		this.isStopped = true;
		try {
			if (sock != null) {
				this.sock.close();
			}
			if (socket != null) {
				this.socket.close();
			}
			if (serverSocket != null) {
				this.serverSocket.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Checks if is stopped.
	 *
	 * @return true, if is stopped
	 */
	public synchronized boolean isStopped() {
		return this.isStopped;
	}
}
